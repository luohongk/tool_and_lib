#pragma once

#include <ATen/core/alias_info.h>

namespace torch {
namespace jit {

using ::c10::AliasInfo;

} // namespace jit
} // namespace torch
