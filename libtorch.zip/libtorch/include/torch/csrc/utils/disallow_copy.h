#pragma once

#include <ATen/Utils.h>

#define TH_DISALLOW_COPY_AND_ASSIGN AT_DISALLOW_COPY_AND_ASSIGN
