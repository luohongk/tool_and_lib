#pragma once

#include <torch/csrc/autograd/custom_function.h>
