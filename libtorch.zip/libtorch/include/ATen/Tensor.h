#pragma once
#include <ATen/core/Tensor.h>
